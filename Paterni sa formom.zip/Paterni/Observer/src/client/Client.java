/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_observer.BinaryObserver;
import concrete_observer.HexaObserver;
import concrete_observer.OctalObserver;
import concrete_subject.ConcreteSubject;
import forms.Form;
import subject.Subject;

/**
 *
 * @author Lazar
 */
public class Client {
    public static void main(String[] args) {
      Form form=new Form();
      form.setVisible(true);
   }
}
