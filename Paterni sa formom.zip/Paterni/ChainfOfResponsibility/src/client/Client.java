/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_handler.AssistantCook;
import concrete_handler.HeadChef;
import concrete_handler.SousChef;
import handler.Cook;

/**
 *
 * @author Lazar
 */
public class Client {
    private static Cook makeChainOfCooks(){
        Cook headChef=new HeadChef(Cook.HEADCHEFLEVEL);
        Cook sousChef=new SousChef(Cook.SOUSCHEFLEVEL);
        Cook assistantCook=new AssistantCook(Cook.ASSISTANTCOOKLEVEL);
        
        headChef.setNextCook(sousChef);
        sousChef.setNextCook(assistantCook);
        
        return headChef;
    }
    
    public static void main(String[] args) {
        Cook chainOfCooks=makeChainOfCooks();
        
        chainOfCooks.delegate(3);
        chainOfCooks.delegate(2);
        chainOfCooks.delegate(1);
        
    }
}
