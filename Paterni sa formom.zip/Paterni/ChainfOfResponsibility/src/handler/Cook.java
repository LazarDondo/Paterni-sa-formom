/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package handler;

import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Lazar
 */
public abstract class Cook {
    public static int HEADCHEFLEVEL=3;
    public static int SOUSCHEFLEVEL=2;
    public static int ASSISTANTCOOKLEVEL=1;
    
    protected int level;
    
    protected Cook nextCook;

    public void setNextCook(Cook nextCook){
      this.nextCook = nextCook;
   }

   public String delegate(int level){
       String text="";
      if(this.level <= level){
         text+=write();
      }
      if(nextCook !=null){
         text+=nextCook.delegate(level);
      }
      return text;
   }
   
   abstract protected String write();
    
}
