/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package invoker;

import command.Command;

/**
 *
 * @author Lazar
 */
public class SimpleRemoteControl {
    Command slot;  // only one button 
  
    public SimpleRemoteControl() 
    { 
    } 
  
    public void setCommand(Command command) 
    { 
        slot = command; 
    } 
  
    public String buttonWasPressed() 
    { 
        return slot.execute(); 
    } 
}
