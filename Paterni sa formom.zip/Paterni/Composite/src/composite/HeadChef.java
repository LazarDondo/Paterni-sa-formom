/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package composite;

import component.Cook;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lazar
 */
public class HeadChef implements Cook{

    private List<Cook> cookList=new ArrayList<Cook>();
    
    
    @Override
    public String showDetails() {
        String details="";
        for (Cook cook : cookList) {
            details+=cook.showDetails()+"\n";
        }
        return details;
    }
    
    public void addCook(Cook cook){
        cookList.add(cook);
    }
    
    public void removeCook(Cook cook){
        cookList.remove(cook);
    }
    
    
    
}
