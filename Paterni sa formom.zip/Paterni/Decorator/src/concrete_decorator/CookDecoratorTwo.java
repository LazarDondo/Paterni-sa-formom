/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_decorator;

import component.Cook;
import decorator.CookDecorator;

/**
 *
 * @author Lazar
 */
public class CookDecoratorTwo extends CookDecorator{
    Cook cook;

    public CookDecoratorTwo(Cook cook) {
        this.cook = cook;
    }
    
    @Override
    public String getDetails() {
       return cook.getDetails()+". Main dish is stuffed lamb.";
    }

    @Override
    public String getPosition() {
        return cook.getPosition()+". This position is very stressful.";
    }
}
