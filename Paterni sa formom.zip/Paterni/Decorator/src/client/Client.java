/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import component.Cook;
import concrete_component.HeadChef;
import concrete_component.SousChef;
import concrete_decorator.CookDecoratorOne;
import concrete_decorator.CookDecoratorTwo;
import forms.Form;

/**
 *
 * @author Lazar
 */
public class Client {
    public static void main(String[] args) {
        Form form=new Form();
        form.setVisible(true);
       
    }
}
