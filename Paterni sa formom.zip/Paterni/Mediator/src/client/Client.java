/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_colleague.Flight;
import concrete_colleague.Runway;
import concrete_mediator.ATCMediator;
import forms.Form;
import mediator.IATCMediator;

/**
 *
 * @author Lazar
 */
public class Client {

    public static void main(String args[]) {

        Form form=new Form();
        form.setVisible(true);

    }
}
