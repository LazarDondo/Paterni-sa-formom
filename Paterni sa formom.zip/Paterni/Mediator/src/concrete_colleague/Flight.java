/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_colleague;

import colleague.Command;
import mediator.IATCMediator;

/**
 *
 * @author Lazar
 */
public class Flight implements Command {

    private IATCMediator atcMediator;

    public Flight(IATCMediator atcMediator) {
        this.atcMediator = atcMediator;
    }

    public String land() {
        String result = "";
        if (atcMediator.isLandingOk()) {
            result = "Successfully Landed.";
        } else {
            result = "Waiting for landing.";
        }
        return result;
    }

    public String getReady() {
        atcMediator.setLandingStatus(true);
        return "Ready for landing.";
    }
    
     public String isNotReady() {
        atcMediator.setLandingStatus(false);
        return "Plain is not ready for landing.";
    }
}
