/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_creator;

import concrete_product.Offer;
import concrete_product_appetizer.VenecijaAppetizer;
import concrete_product_dessert.VenecijaDessert;
import concrete_product_main_dish.VenecijaMainDish;
import creator.Restaurant;
import product.IOffer;

/**
 *
 * @author Lazar
 */
public class Venecija extends Restaurant{

    @Override
    public IOffer createOffer() {
        Offer off=new Offer();
        appetizer=new VenecijaAppetizer();
        mainDish=new VenecijaMainDish();
        dessert=new VenecijaDessert();
        off.offer = "\nAppetizer: " + appetizer.getAppetizer() + "\nMain dish: " + mainDish.getMainDish() + "\nDessert: " + dessert.getDessert();
        return off;
    }

    @Override
    public String toString() {
        return "Venecija";
    }
    
    
    
}
