/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_creator;

import concrete_product.Offer;
import concrete_product_appetizer.SaranAppetizer;
import concrete_product_dessert.SaranDessert;
import concrete_product_main_dish.SaranMainDish;
import creator.Restaurant;
import product.IOffer;

/**
 *
 * @author Lazar
 */
public class Saran extends Restaurant{

    @Override
    public IOffer createOffer() {
        Offer off=new Offer();
        appetizer=new SaranAppetizer();
        mainDish=new SaranMainDish();
        dessert=new SaranDessert();
        off.offer = "\nAppetizer: " + appetizer.getAppetizer() + "\nMain dish: " + mainDish.getMainDish() + "\nDessert: " + dessert.getDessert();
        return off;
    }
    @Override
    public String toString() {
        return "Saran";
    }
}
