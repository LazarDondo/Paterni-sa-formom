/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package creator;

import abstract_product.Appetizer;
import abstract_product.Dessert;
import abstract_product.MainDish;
import product.IOffer;

/**
 *
 * @author Lazar
 */
public abstract class Restaurant {

    public Appetizer appetizer;
    public MainDish mainDish;
    public Dessert dessert;
    public IOffer offer;

    public void create() {
        offer = createOffer();
    }

    public abstract IOffer createOffer();

    public String getOffer() {
        return this + "'s offer:" + offer.getOffer();
    }
}
