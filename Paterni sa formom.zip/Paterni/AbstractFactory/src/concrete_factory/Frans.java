/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_factory;

import abstract_factory.Restaurant;
import abstract_product.Appetizer;
import abstract_product.Dessert;
import abstract_product.MainDish;
import concrete_product_appetizer.FransAppetizer;
import concrete_product_dessert.FransDessert;
import concrete_product_main_dish.FransMainDish;

/**
 *
 * @author Lazar
 */
public class Frans implements Restaurant{

    @Override
    public Appetizer makeAppetizer() {
       return new FransAppetizer();
    }

    @Override
    public MainDish makeMainDish() {
        return new FransMainDish();
    }

    @Override
    public Dessert makeDessert() {
        return new FransDessert();
    }
    
     @Override
    public String toString() {
        return "Frans";
    }
    
}
