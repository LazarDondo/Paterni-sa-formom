/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstract_factory;

import abstract_product.Appetizer;
import abstract_product.Dessert;
import abstract_product.MainDish;

/**
 *
 * @author Lazar
 */
public interface Restaurant {
    Appetizer makeAppetizer();
    MainDish makeMainDish();
    Dessert makeDessert();
}
