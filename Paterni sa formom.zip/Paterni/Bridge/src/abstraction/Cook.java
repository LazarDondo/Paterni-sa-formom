/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

import implementor.Dish;

/**
 *
 * @author Lazar
 */
public abstract class Cook {
    protected Dish appetizer; 
    protected Dish mainDish;
    protected Dish desert;

    public Cook(Dish appetizer, Dish mainDish, Dish desert) {
        this.appetizer = appetizer;
        this.mainDish = mainDish;
        this.desert = desert;
    }
    
    abstract public String makeDish();
    
}
