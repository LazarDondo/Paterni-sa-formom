/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import abstract_expression.Expression;
import forms.Form;
import nontreminal_expression.AndExpression;
import nontreminal_expression.OrExpression;
import terminal_expression.TerminalExpression;

/**
 *
 * @author Lazar
 */
public class Client {
    public static void main(String[] args)  
    { 
        Form form=new Form();
        form.setVisible(true);
    } 
}
