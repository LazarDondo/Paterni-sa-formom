/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_prototype;

import concrete_product_appetizer.FransAppetizer;
import concrete_product_dessert.FransDessert;
import concrete_product_main_dish.FransMainDish;
import product.Offer;
import prototype.Restaurant;

/**
 *
 * @author Lazar
 */
public class Frans extends Restaurant{
    
    public Frans() {
        o = new Offer();
    }

    public Frans(Frans frans) {
        o = new Offer();
        o.offer = new String(frans.o.offer);
    }

    @Override
    public void makeAppetizer() {
        appetizer = new FransAppetizer();
    }

    @Override
    public void makeMainDish() {
        mainDish = new FransMainDish();
    }

    @Override
    public void makeDessert() {
        dessert = new FransDessert();
    }

    @Override
    public void createOffer() {
        o.offer = "\nAppetizer: " + appetizer.getAppetizer() + "\nMain dish: " + mainDish.getMainDish() + "\nDessert: " + dessert.getDessert();
    }

    @Override
    public Restaurant Clone() {
       return new Frans(this);
    }

    @Override
    public String toString() {
        return "Frans";
    }
    
    
}
