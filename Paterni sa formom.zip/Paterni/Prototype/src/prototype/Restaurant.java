/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prototype;

import abstract_product.Appetizer;
import abstract_product.Dessert;
import abstract_product.MainDish;
import product.Offer;

/**
 *
 * @author Lazar
 */
public abstract class Restaurant {

    public Appetizer appetizer;
    public MainDish mainDish;
    public Dessert dessert;
    public Offer o;

    public abstract void makeAppetizer();

    public abstract void makeMainDish();

    public abstract void makeDessert();

    public abstract void createOffer();

    public String getOffer() {
        return this+"s offer:"+o.offer;
    }

    public abstract Restaurant Clone();
}
