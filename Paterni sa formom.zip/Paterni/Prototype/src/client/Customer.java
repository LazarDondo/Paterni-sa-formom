/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_prototype.Frans;
import concrete_prototype.Venecija;
import forms.Form;
import prototype.Restaurant;

/**
 *
 * @author Lazar
 */
public class Customer {

    public static void main(String[] args) {
        Form form = new Form();
        form.setVisible(true);

    }

}
