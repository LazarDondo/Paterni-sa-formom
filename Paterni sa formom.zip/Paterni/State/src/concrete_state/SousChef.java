/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_state;

import context.Context;
import state.Cook;

/**
 *
 * @author Lazar
 */
public class SousChef implements Cook {

    @Override
    public String makeDish(Context context) {

        context.setCook(this);
        return currentState();
    }

    @Override
    public String currentState() {
        return "Sous chef is preparing dessert.";
    }
}
