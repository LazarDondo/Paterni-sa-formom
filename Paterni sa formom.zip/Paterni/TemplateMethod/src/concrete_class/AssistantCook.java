/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_class;

import abstract_class.Cook;

/**
 *
 * @author Lazar
 */
public class AssistantCook extends Cook{

    @Override
    protected String makeAppetizer() {
        return "Assisant cook's appetizer.";
    }

    @Override
    protected String makeMainDish() {
        return "Assisant cook's main dish.";
    }

    @Override
    protected String makeDessert() {
        return "Assisant cook's dessert.";
    }
    
}
