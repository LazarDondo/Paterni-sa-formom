/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_class;

import abstract_class.Cook;

/**
 *
 * @author Lazar
 */
public class HeadChef extends Cook{

      @Override
    protected String makeAppetizer() {
        return "Head chef's appetizer.";
    }

    @Override
    protected String makeMainDish() {
        return "Head chef's main dish.";
    }

    @Override
    protected String makeDessert() {
         return "Head chef's dessert.";
    }
    
}
