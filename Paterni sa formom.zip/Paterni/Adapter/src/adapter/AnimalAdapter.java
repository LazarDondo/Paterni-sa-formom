/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adapter;

import adaptee.Animal;
import target.AnimalTarget;

/**
 *
 * @author Lazar
 */
public class AnimalAdapter implements AnimalTarget{
    Animal animal;

    public AnimalAdapter(Animal animal) {
        this.animal = animal;
    }
    
    
    @Override
    public String animalSound() {
      return animal.makeSound();
    }

    @Override
    public String animalMovement() {
      return animal.move();
    }
    
}
