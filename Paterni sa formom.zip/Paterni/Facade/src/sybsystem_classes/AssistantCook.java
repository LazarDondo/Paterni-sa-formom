/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sybsystem_classes;

/**
 *
 * @author Lazar
 */
public class AssistantCook implements Cook{

    @Override
    public String details() {
        return "Assistant cook";
    }
    
}
