/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package facade;

import sybsystem_classes.AssistantCook;
import sybsystem_classes.HeadChef;
import sybsystem_classes.SousChef;

/**
 *
 * @author Lazar
 */
public class RestaurantManager {

    private HeadChef headChef;
    private SousChef sousChef;
    private AssistantCook assistantCook;

    public RestaurantManager() {
        headChef = new HeadChef();
        sousChef = new SousChef();
        assistantCook = new AssistantCook();
    }

    public String assignHeadChef() {
        return headChef.details();
    }

    public String assignSousChef() {
        return sousChef.details();
    }

    public String assignAssitantCook() {
        return assistantCook.details();
    }
}
