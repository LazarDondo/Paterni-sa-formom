/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_builder;

import builder.Restaurant;
import concrete_product_appetizer.SaranAppetizer;
import concrete_product_dessert.SaranDessert;
import concrete_product_main_dish.SaranMainDish;
import product.Offer;

/**
 *
 * @author Lazar
 */
public class Saran extends Restaurant {

    public Saran() {
        o = new Offer();
    }

    @Override
    public void makeAppetizer() {
        appetizer = new SaranAppetizer();
    }

    @Override
    public void makeMainDish() {
        mainDish = new SaranMainDish();
    }

    @Override
    public void makeDessert() {
        dessert = new SaranDessert();
    }

    @Override
    public void createOffer() {
        o.offer = "Restauran Saran offer:\nAppetizer: " + appetizer.getAppetizer() + "\nMain dish: " + mainDish.getMainDish() + "\nDessert: " + dessert.getDessert();
    }

    @Override
    public String toString() {
        return "Saran";
    }

}
