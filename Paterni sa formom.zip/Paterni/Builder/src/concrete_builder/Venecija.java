/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_builder;

import product.Offer;
import builder.Restaurant;
import concrete_product_appetizer.VenecijaAppetizer;
import concrete_product_dessert.VenecijaDessert;
import concrete_product_main_dish.VenecijaMainDish;

/**
 *
 * @author Lazar
 */
public class Venecija extends Restaurant {

    public Venecija() {
        o = new Offer();
    }

    @Override
    public void makeAppetizer() {
        appetizer = new VenecijaAppetizer();
    }

    @Override
    public void makeMainDish() {
        mainDish = new VenecijaMainDish();
    }

    @Override
    public void makeDessert() {
        dessert = new VenecijaDessert();
    }

    public void createOffer() {
        o.offer = "Restaurant Venecija offer:\nAppetizer: " + appetizer.getAppetizer() + "\nMain dish: " + mainDish.getMainDish() + "\nDessert: " + dessert.getDessert();
    }

    @Override
    public String toString() {
        return "Venecija";
    }

    

}
