/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proxy;

import java.util.ArrayList;
import java.util.List;
import real_subject.ConcreteEmployee;
import subject.Employee;

/**
 *
 * @author Lazar
 */
public class HiringManager implements Employee {

    private Employee empoloyee = new ConcreteEmployee();
    private List<String> bannedEmployees;

    public HiringManager() {
        bannedEmployees=new ArrayList<String>();
        bannedEmployees.add("aaa");
        bannedEmployees.add("bbb");
        bannedEmployees.add("ccc");
    }

    @Override
    public String hire(String name) throws Exception {
        if(bannedEmployees.contains(name.toLowerCase())){
            throw new Exception(name+" is banned!");
        }
        return empoloyee.hire(name);
    }

}
