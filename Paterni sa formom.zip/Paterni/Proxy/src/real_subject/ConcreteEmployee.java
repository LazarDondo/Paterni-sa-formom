/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package real_subject;

import subject.Employee;

/**
 *
 * @author Lazar
 */
public class ConcreteEmployee implements Employee {

    @Override
    public String hire(String name) throws Exception {
        return name+" is hired.";
    }

   

}
