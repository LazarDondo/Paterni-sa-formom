/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_element;

import element.ItemElement;
import visitor.ShoppingCartVisitor;

/**
 *
 * @author Lazar
 */
public class Fruit implements ItemElement {

    private int pricePerKg;
    private int weight;
    private String name;

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public Fruit(int priceKg, int wt, String nm) {
        this.pricePerKg = priceKg;
        this.weight = wt;
        this.name = nm;
    }

    public int getPricePerKg() {
        return pricePerKg;
    }

    public int getWeight() {
        return weight;
    }

    public String getName() {
        return this.name;
    }

    @Override
    public int accept(ShoppingCartVisitor visitor) {
        return visitor.visit(this);
    }

    @Override
    public String toString() {
        return name;
    }
    
    public String getDetails(){
        return "Product name: "+name+", Weight: "+weight+", Price per kg: "+pricePerKg;
    }


}
