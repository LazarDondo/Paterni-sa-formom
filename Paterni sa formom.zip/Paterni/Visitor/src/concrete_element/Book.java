/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_element;

import element.ItemElement;
import visitor.ShoppingCartVisitor;

/**
 *
 * @author Lazar
 */
public class Book implements ItemElement {

    private int price;
    private int isbnNumber;

    public Book(int cost, int isbn) {
        this.price = cost;
        this.isbnNumber = isbn;
    }

    public int getPrice() {
        return price;
    }

    public int getIsbnNumber() {
        return isbnNumber;
    }

    @Override
    public int accept(ShoppingCartVisitor visitor) {
        return visitor.visit(this);
    }
    
    public String getDetails(){
        return "ISBN: "+isbnNumber+", Price: "+price;
    }
}
