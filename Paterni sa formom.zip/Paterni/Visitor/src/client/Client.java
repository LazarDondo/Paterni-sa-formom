/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_element.Book;
import concrete_element.Fruit;
import concrete_visitor.ShoppingCartVisitorImpl;
import element.ItemElement;
import forms.Form;
import visitor.ShoppingCartVisitor;

/**
 *
 * @author Lazar
 */
public class Client {
    public static void main(String[] args)  
    { 
        Form form=new Form();
        form.setVisible(true);
    } 
   
}
