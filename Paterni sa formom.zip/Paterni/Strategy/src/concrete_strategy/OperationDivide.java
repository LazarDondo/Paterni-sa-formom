/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_strategy;

import strategy.Strategy;

/**
 *
 * @author Lazar
 */
public class OperationDivide implements Strategy {

    @Override
    public int doOperation(int num1, int num2) {
        if(num2==0){
            return 0;
        }
        return num1 / num2;
    }
}
